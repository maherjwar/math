package com.maher.geogebraar;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView web;

    /** جسر يستدعيه الموقع لحفظ صورة المخطط في الجهاز. */
    public class Bridge {
        @JavascriptInterface
        public void saveImage(String dataUrl, String fileName) {
            try {
                String b64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                final String where = writePng(bytes, fileName);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم الحفظ في: " + where, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                final String msg = e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تعذّر الحفظ: " + msg, Toast.LENGTH_LONG).show());
            }
        }
    }

    private String writePng(byte[] bytes, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GeoGebraAR");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("تعذّر إنشاء الملف");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                os.write(bytes);
            }
            return "الصور/GeoGebraAR";
        }
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "GeoGebraAR");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذّر إنشاء المجلد");
        try (FileOutputStream fos = new FileOutputStream(new File(dir, name))) {
            fos.write(bytes);
        }
        return dir.getAbsolutePath();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
